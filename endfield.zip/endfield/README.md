# Arknights: Endfield – 3DMigoto Loader

This is a 3DMigoto loader for **Arknights: Endfield**.


## How to use

1. Run `loader.exe`.
2. Open the official game launcher.
3. Enable **“Launch with DirectX 11”**.
4. Launch the game.

---

## Important warning

- This tool modifies the game process at runtime.
- Using mods or injection tools **may violate the game’s Terms of Service**.
- Online or live-service games may carry a **risk of account suspension or ban**.

**Use entirely at your own responsibility.**

---

## License

This project is licensed under **GPL-3.0**.

This project is based on **GI-Model-Importer** by SilentNightSound
and inherits its license.
https://github.com/SilentNightSound/GI-Model-Importer

Corresponding source code is provided in this repository.
